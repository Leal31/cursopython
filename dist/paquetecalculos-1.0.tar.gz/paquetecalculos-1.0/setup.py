from setuptools import setup

setup(name='paquetecalculos',
      version='1.0',
      description='Hace calculos matematicos basicos',
      author='Emanuel Leal',
      author_email='lealemanuel31@protonmail.com',
      packages=['calculos', 'calculos.basicos']
        )

